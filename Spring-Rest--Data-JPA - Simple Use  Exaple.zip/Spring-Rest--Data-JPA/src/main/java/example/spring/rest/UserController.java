package example.spring.rest;

import java.util.Collection;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	private UserReposiory userRepo;
	
	public UserController(UserReposiory userRepo) {
		super();
		this.userRepo = userRepo;
	}

	@GetMapping("/create")
	public void create() {
		userRepo.save(new User(101, "Rahul"));
	}
	@GetMapping("/getAll")
	public Collection<User> getAllUsers(){
		return userRepo.findAll();
	}
	@GetMapping("/getOne")
	public User getOneUser() {
		return userRepo.findById(101).get();
	}
}
